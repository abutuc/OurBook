﻿Imports System.Data.SqlClient

Public Class BookPage
    Dim CN As SqlConnection
    Dim CMD As SqlCommand

    Private Sub BookPage_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CN = New SqlConnection("data source=tcp:mednat.ieeta.pt\SQLSERVER,8101;integrated security=false;initial catalog=p5g1; uid = p5g1; password = AndreGoncaloRumoao20")
        CMD = New SqlCommand
        CMD.Connection = CN
        CMD.CommandText = "EXEC GetBookList 1"
        CN.Open()
        Dim RDR As SqlDataReader
        RDR = CMD.ExecuteReader()
        Debug.Print(RDR.ToString())
        LivrosDepositados.Items.Clear()
        While RDR.Read()
            Dim L As New Livro
            L.UserID = RDR.Item("IDuser")
            L.Codigo = RDR.Item("Codigo")
            L.Nome = RDR.Item("Nome")
            L.Autor = RDR.Item("Autor")
            L.Edicao = RDR.Item("Edicao")
            L.Editora = RDR.Item("Editora")
            LivrosDepositados.Items.Add(L)
        End While
        CN.Close()
    End Sub


    Private Sub LoadList()
        CMD.CommandText = "EXEC GetBookList 1"
        CN.Open()
        Dim RDR As SqlDataReader
        RDR = CMD.ExecuteReader()
        Debug.Print(RDR.ToString())
        LivrosDepositados.Items.Clear()
        While RDR.Read()
            Dim L As New Livro
            L.UserID = RDR.Item("IDuser")
            L.Codigo = RDR.Item("Codigo")
            L.Nome = RDR.Item("Nome")
            L.Autor = RDR.Item("Autor")
            L.Edicao = RDR.Item("Edicao")
            L.Editora = RDR.Item("Editora")
            LivrosDepositados.Items.Add(L)
        End While
        CN.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim book As New Livro
        Try
            book.UserID = 1
            book.Codigo = GenerateCode()
            If TextBox1.Text <> "" Then
                book.Nome = TextBox1.Text
            Else
                MessageBox.Show("First Name Value Shouldn't Be Empty")
                Return
            End If

            If TextBox2.Text <> "" Then
                book.Autor = TextBox2.Text
            Else
                MessageBox.Show("Last Name Value Shouldn't Be Empty")
                Return
            End If

            If TextBox3.Text <> "" Then
                book.Edicao = CInt(TextBox3.Text)
            Else
                MessageBox.Show("Username Value Shouldn't Be Empty")
                Return
            End If

            If TextBox4.Text <> "" Then
                book.Editora = TextBox4.Text
            Else
                MessageBox.Show("Email Value Shouldn't Be Empty")
                Return
            End If

        Catch ex As Exception
            MessageBox.Show("Unable to Create A New User Due To The Invalid Data Inputted")
            Return
        End Try

        CMD.CommandText = "EXEC CreateNewBook @IDuser, @Codigo, @Nome, @Autor, @Edicao, @Editora"
        CMD.Parameters.Clear()
        CMD.Parameters.AddWithValue("@IDUser", book.UserID)
        CMD.Parameters.AddWithValue("@Codigo", book.Codigo)
        CMD.Parameters.AddWithValue("@Nome", book.Nome)
        CMD.Parameters.AddWithValue("@Autor", book.Autor)
        CMD.Parameters.AddWithValue("@Edicao", book.Edicao)
        CMD.Parameters.AddWithValue("@Editora", book.Editora)
        CN.Open()
        Try
            MessageBox.Show(CMD.ExecuteNonQuery())
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Throw New Exception("Failed to update user in database. ")
        Finally
            ClearTextBoxes()
            CN.Close()
        End Try
        ClearTextBoxes()
        CN.Close()
        LoadList()
    End Sub


    Private Function GenerateCode() As Integer
        Dim code As New Integer
        CMD.CommandText = "EXEC GetMaxLivroCode"
        CN.Open()
        Dim RDR As SqlDataReader
        RDR = CMD.ExecuteReader
        While RDR.Read
            code = RDR.Item("MAX_CODE")
        End While
        CN.Close()
        Return code + 1
    End Function

    Private Sub ClearTextBoxes()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Close()
    End Sub
End Class