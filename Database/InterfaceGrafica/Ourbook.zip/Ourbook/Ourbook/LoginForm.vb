﻿Public Class LoginForm
    Private Sub AdminButton_Click(sender As Object, e As EventArgs) Handles AdminButton.Click
        Dim adminForm As New Form1
        adminForm.Show()
    End Sub

    Private Sub UserButton_Click(sender As Object, e As EventArgs) Handles UserButton.Click
        Dim userPage As New UserPage
        userPage.Show()
    End Sub
End Class