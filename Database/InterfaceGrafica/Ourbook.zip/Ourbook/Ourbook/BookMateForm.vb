﻿Imports System.Data.SqlClient
Public Class BookMateForm
    Dim CN As SqlConnection
    Dim CMD As SqlCommand

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles FilterSelectBox.SelectedIndexChanged

        CN.Open()

        CMD.CommandText = "SELECT * FROM UTILIZADOR"
        If FilterSelectBox.SelectedItem.ToString() = "Number_of_Books" Then
            CMD.CommandText = "SELECT Fname,Lname,COUNT(Codigo) AS NumberofBooks FROM (UTILIZADOR JOIN LIVRO ON UTILIZADOR.ID=LIVRO.IDuser) GROUP BY Fname,Lname"
        ElseIf FilterSelectBox.SelectedItem.ToString() = "Adventure" Then
            CMD.CommandText = "SELECT Fname,Lname FROM (UTILIZADOR JOIN PREFERENCIAS_LITERARIAS ON UTILIZADOR.ID=PREFERENCIAS_LITERARIAS.IDuser) WHERE PREFERENCIAS_LITERARIAS.PreferenciaLiteraria LIKE 'Adventure' GROUP BY Fname,Lname"
        ElseIf FilterSelectBox.SelectedItem.ToString() = "Famous" Then
            CMD.CommandText = "SELECT Fname,Lname FROM (UTILIZADOR JOIN PREFERENCIAS_LITERARIAS ON UTILIZADOR.ID=PREFERENCIAS_LITERARIAS.IDuser) WHERE PREFERENCIAS_LITERARIAS.PreferenciaLiteraria LIKE 'Famous' GROUP BY Fname,Lname"
        ElseIf FilterSelectBox.SelectedItem.ToString() = "Fantasy" Then
            CMD.CommandText = "SELECT Fname,Lname FROM (UTILIZADOR JOIN PREFERENCIAS_LITERARIAS ON UTILIZADOR.ID=PREFERENCIAS_LITERARIAS.IDuser) WHERE PREFERENCIAS_LITERARIAS.PreferenciaLiteraria LIKE 'Fantasy' GROUP BY Fname,Lname"
        ElseIf FilterSelectBox.SelectedItem.ToString() = "Fictional" Then
            CMD.CommandText = "SELECT Fname,Lname FROM (UTILIZADOR JOIN PREFERENCIAS_LITERARIAS ON UTILIZADOR.ID=PREFERENCIAS_LITERARIAS.IDuser) WHERE PREFERENCIAS_LITERARIAS.PreferenciaLiteraria LIKE 'Fictional' GROUP BY Fname,Lname"
        ElseIf FilterSelectBox.SelectedItem.ToString() = "Historic" Then
            CMD.CommandText = "SELECT Fname,Lname FROM (UTILIZADOR JOIN PREFERENCIAS_LITERARIAS ON UTILIZADOR.ID=PREFERENCIAS_LITERARIAS.IDuser) WHERE PREFERENCIAS_LITERARIAS.PreferenciaLiteraria LIKE 'Historic' GROUP BY Fname,Lname"
        ElseIf FilterSelectBox.SelectedItem.ToString() = "Humanity" Then
            CMD.CommandText = "SELECT Fname,Lname FROM (UTILIZADOR JOIN PREFERENCIAS_LITERARIAS ON UTILIZADOR.ID=PREFERENCIAS_LITERARIAS.IDuser) WHERE PREFERENCIAS_LITERARIAS.PreferenciaLiteraria LIKE 'Humanity' GROUP BY Fname,Lname"
        ElseIf FilterSelectBox.SelectedItem.ToString() = "Revolutionary_Christianism" Then
            CMD.CommandText = "SELECT Fname,Lname FROM (UTILIZADOR JOIN PREFERENCIAS_LITERARIAS ON UTILIZADOR.ID=PREFERENCIAS_LITERARIAS.IDuser) WHERE PREFERENCIAS_LITERARIAS.PreferenciaLiteraria LIKE 'Revolutionary_Christianism' GROUP BY Fname,Lname"
        ElseIf FilterSelectBox.SelectedItem.ToString() = "Sports" Then
            CMD.CommandText = "SELECT Fname,Lname FROM (UTILIZADOR JOIN PREFERENCIAS_LITERARIAS ON UTILIZADOR.ID=PREFERENCIAS_LITERARIAS.IDuser) WHERE PREFERENCIAS_LITERARIAS.PreferenciaLiteraria LIKE 'Sports' GROUP BY Fname,Lname"
        End If
        Dim RDR As SqlDataReader
        RDR = CMD.ExecuteReader
        UserList.Items.Clear()
        While RDR.Read
            Dim U As New User
            U.UserFirstName = RDR.Item("Fname")
            U.UserLastName = RDR.Item("Lname")
            UserList.Items.Add(U)
        End While
        CN.Close()
    End Sub

    Private Sub BookMateForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        BookList.Visible = False
        NotShowBooks.Visible = False
        CN = New SqlConnection("data source=tcp:mednat.ieeta.pt\SQLSERVER,8101;integrated security=false;initial catalog=p5g1; uid = p5g1; password = AndreGoncaloRumoao20")
        CMD = New SqlCommand
        CN.Open()
        CMD.Connection = CN
        CMD.CommandText = "EXEC GetUserList"
        Dim RDR As SqlDataReader
        RDR = CMD.ExecuteReader
        UserList.Items.Clear()
        While RDR.Read
            Dim U As New User
            U.UserID = RDR.Item("ID")
            U.UserFirstName = RDR.Item("Fname")
            U.UserLastName = RDR.Item("Lname")
            UserList.Items.Add(U)
        End While
        CN.Close()
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles SearchBox.TextChanged
        CN.Open()
        CMD.CommandText = "SELECT Fname,Lname FROM UTILIZADOR WHERE Fname LIKE '%" + SearchBox.Text + "%' OR Lname LIKE '%" + SearchBox.Text + "%'"
        Dim RDR As SqlDataReader
        RDR = CMD.ExecuteReader
        UserList.Items.Clear()
        While RDR.Read
            Dim U As New User
            U.UserFirstName = RDR.Item("Fname")
            U.UserLastName = RDR.Item("Lname")
            UserList.Items.Add(U)
        End While
        CN.Close()
    End Sub

    Private Sub UserList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles UserList.SelectedIndexChanged
        CN.Open()
        CMD.CommandText = "SELECT Codigo, Nome FROM (UTILIZADOR JOIN LIVRO ON UTILIZADOR.ID=LIVRO.IDuser) WHERE LIVRO.IDuser=" + UserList.SelectedItem.UserID.ToString()
        Dim RDR As SqlDataReader
        RDR = CMD.ExecuteReader
        BookList.Items.Clear()
        While RDR.Read
            Dim L As New Livro
            L.Codigo = RDR.Item("Codigo")
            L.Nome = RDR.Item("Nome")
            BookList.Items.Add(L)
        End While
        CN.Close()
    End Sub

    Private Sub MakeTrade_Click(sender As Object, e As EventArgs) Handles MakeTrade.Click
        If BookList.SelectedIndex = -1 Then
            MessageBox.Show("You have to select a book in order to make a trade")
        Else
            Dim FormId As Integer = GenerateID() + 1
            Dim EstafetaId As Integer = GenerateIDestafeta()
            CMD.CommandText = "EXEC CreateNewFormularioTroca @IDuser1, @IDuser2, @ID, @Data, @DataDeTroca, @IDEstafeta, @CodigoLivro"
            CMD.Parameters.Clear()
            CMD.Parameters.AddWithValue("@IDuser1", UserList.SelectedItem.UserID)
            CMD.Parameters.AddWithValue("@IDuser2", 7)
            CMD.Parameters.AddWithValue("@ID", FormId)
            CMD.Parameters.AddWithValue("@Data", Today())
            CMD.Parameters.AddWithValue("@DataDeTroca", Today())
            CMD.Parameters.AddWithValue("@IDestafeta", EstafetaId)
            CMD.Parameters.AddWithValue("@CodigoLivro", BookList.SelectedItem.Codigo)
            CN.Open()
            Try
                CMD.ExecuteNonQuery()
            Catch ex As Exception
                MessageBox.Show("An Error Has Occured While submitting Book exchange")
                Throw New Exception("Failed to update user in database. ")
            Finally
                CN.Close()
            End Try
            CN.Close()
            MessageBox.Show("Traded sucessfully!")
        End If
    End Sub

    Private Sub ShowBooks_Click(sender As Object, e As EventArgs) Handles ShowBooks.Click
        BookList.Visible = True
        NotShowBooks.Visible = True
        ShowBooks.Visible = False
    End Sub

    Private Sub NotShowBooks_Click(sender As Object, e As EventArgs) Handles NotShowBooks.Click
        BookList.Visible = False
        NotShowBooks.Visible = False
        ShowBooks.Visible = True
    End Sub

    Private Function GenerateID() As Integer
        Dim id As New Integer
        CMD.CommandText = "EXEC GetMaxFormID"
        CN.Open()
        Dim RDR As SqlDataReader
        RDR = CMD.ExecuteReader
        While RDR.Read
            id = RDR.Item("MAX_ID")
        End While
        CN.Close()
        Return id
    End Function

    Private Function GenerateIDestafeta() As Integer
        Dim id As New Integer
        CMD.CommandText = "SELECT Top 1 ID FROM dbo.ESTAFETA ORDER BY NEWID()"
        CN.Open()
        Dim RDR As SqlDataReader
        RDR = CMD.ExecuteReader
        While RDR.Read
            id = RDR.Item("ID")
        End While
        CN.Close()
        Return id
    End Function
End Class