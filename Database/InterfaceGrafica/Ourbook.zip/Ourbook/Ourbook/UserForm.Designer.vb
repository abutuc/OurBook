﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UserForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TitleFormLabel = New System.Windows.Forms.Label()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.UsersListBox = New System.Windows.Forms.ListBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.FnameTextBox = New System.Windows.Forms.TextBox()
        Me.FnameLabel = New System.Windows.Forms.Label()
        Me.LnameLabel = New System.Windows.Forms.Label()
        Me.LnameTextBox = New System.Windows.Forms.TextBox()
        Me.UsernameLabel = New System.Windows.Forms.Label()
        Me.UsernameTextBox = New System.Windows.Forms.TextBox()
        Me.EmailLabel = New System.Windows.Forms.Label()
        Me.EmailTextBox = New System.Windows.Forms.TextBox()
        Me.BirthdayLabel = New System.Windows.Forms.Label()
        Me.BirthdayPicker = New System.Windows.Forms.DateTimePicker()
        Me.CreateNewUserButton = New System.Windows.Forms.Button()
        Me.LoadUserList = New System.Windows.Forms.Button()
        Me.EditUserButton = New System.Windows.Forms.Button()
        Me.RemoveUserButton = New System.Windows.Forms.Button()
        Me.ConfirmCreateButton = New System.Windows.Forms.Button()
        Me.CancelActionButton = New System.Windows.Forms.Button()
        Me.ConfirmEditButton = New System.Windows.Forms.Button()
        Me.ConfirmDeleteButton = New System.Windows.Forms.Button()
        Me.BackButton = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'TitleFormLabel
        '
        Me.TitleFormLabel.AutoSize = True
        Me.TitleFormLabel.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.TitleFormLabel.Location = New System.Drawing.Point(458, 16)
        Me.TitleFormLabel.Name = "TitleFormLabel"
        Me.TitleFormLabel.Size = New System.Drawing.Size(104, 25)
        Me.TitleFormLabel.TabIndex = 0
        Me.TitleFormLabel.Text = "USER Form"
        '
        'UsersListBox
        '
        Me.UsersListBox.FormattingEnabled = True
        Me.UsersListBox.ItemHeight = 15
        Me.UsersListBox.Location = New System.Drawing.Point(83, 74)
        Me.UsersListBox.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.UsersListBox.Name = "UsersListBox"
        Me.UsersListBox.Size = New System.Drawing.Size(190, 244)
        Me.UsersListBox.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(83, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(154, 15)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Currently registered Users"
        '
        'FnameTextBox
        '
        Me.FnameTextBox.Location = New System.Drawing.Point(394, 74)
        Me.FnameTextBox.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.FnameTextBox.Name = "FnameTextBox"
        Me.FnameTextBox.Size = New System.Drawing.Size(121, 23)
        Me.FnameTextBox.TabIndex = 3
        '
        'FnameLabel
        '
        Me.FnameLabel.AutoSize = True
        Me.FnameLabel.Location = New System.Drawing.Point(310, 76)
        Me.FnameLabel.Name = "FnameLabel"
        Me.FnameLabel.Size = New System.Drawing.Size(67, 15)
        Me.FnameLabel.TabIndex = 4
        Me.FnameLabel.Text = "First Name:"
        '
        'LnameLabel
        '
        Me.LnameLabel.AutoSize = True
        Me.LnameLabel.Location = New System.Drawing.Point(539, 76)
        Me.LnameLabel.Name = "LnameLabel"
        Me.LnameLabel.Size = New System.Drawing.Size(66, 15)
        Me.LnameLabel.TabIndex = 5
        Me.LnameLabel.Text = "Last Name:"
        '
        'LnameTextBox
        '
        Me.LnameTextBox.Location = New System.Drawing.Point(616, 74)
        Me.LnameTextBox.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.LnameTextBox.Name = "LnameTextBox"
        Me.LnameTextBox.Size = New System.Drawing.Size(151, 23)
        Me.LnameTextBox.TabIndex = 6
        '
        'UsernameLabel
        '
        Me.UsernameLabel.AutoSize = True
        Me.UsernameLabel.Location = New System.Drawing.Point(310, 128)
        Me.UsernameLabel.Name = "UsernameLabel"
        Me.UsernameLabel.Size = New System.Drawing.Size(63, 15)
        Me.UsernameLabel.TabIndex = 7
        Me.UsernameLabel.Text = "Username:"
        '
        'UsernameTextBox
        '
        Me.UsernameTextBox.Location = New System.Drawing.Point(392, 125)
        Me.UsernameTextBox.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.UsernameTextBox.Name = "UsernameTextBox"
        Me.UsernameTextBox.Size = New System.Drawing.Size(123, 23)
        Me.UsernameTextBox.TabIndex = 8
        '
        'EmailLabel
        '
        Me.EmailLabel.AutoSize = True
        Me.EmailLabel.Location = New System.Drawing.Point(539, 130)
        Me.EmailLabel.Name = "EmailLabel"
        Me.EmailLabel.Size = New System.Drawing.Size(39, 15)
        Me.EmailLabel.TabIndex = 9
        Me.EmailLabel.Text = "Email:"
        '
        'EmailTextBox
        '
        Me.EmailTextBox.Location = New System.Drawing.Point(616, 128)
        Me.EmailTextBox.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.EmailTextBox.Name = "EmailTextBox"
        Me.EmailTextBox.Size = New System.Drawing.Size(151, 23)
        Me.EmailTextBox.TabIndex = 10
        '
        'BirthdayLabel
        '
        Me.BirthdayLabel.AutoSize = True
        Me.BirthdayLabel.Location = New System.Drawing.Point(310, 170)
        Me.BirthdayLabel.Name = "BirthdayLabel"
        Me.BirthdayLabel.Size = New System.Drawing.Size(54, 15)
        Me.BirthdayLabel.TabIndex = 11
        Me.BirthdayLabel.Text = "Birthday:"
        '
        'BirthdayPicker
        '
        Me.BirthdayPicker.Location = New System.Drawing.Point(392, 166)
        Me.BirthdayPicker.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.BirthdayPicker.Name = "BirthdayPicker"
        Me.BirthdayPicker.Size = New System.Drawing.Size(219, 23)
        Me.BirthdayPicker.TabIndex = 12
        Me.BirthdayPicker.Value = New Date(2022, 6, 8, 22, 19, 43, 0)
        '
        'CreateNewUserButton
        '
        Me.CreateNewUserButton.Location = New System.Drawing.Point(367, 225)
        Me.CreateNewUserButton.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.CreateNewUserButton.Name = "CreateNewUserButton"
        Me.CreateNewUserButton.Size = New System.Drawing.Size(108, 42)
        Me.CreateNewUserButton.TabIndex = 13
        Me.CreateNewUserButton.Text = "Create New User"
        Me.CreateNewUserButton.UseVisualStyleBackColor = True
        '
        'LoadUserList
        '
        Me.LoadUserList.Location = New System.Drawing.Point(83, 47)
        Me.LoadUserList.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.LoadUserList.Name = "LoadUserList"
        Me.LoadUserList.Size = New System.Drawing.Size(82, 22)
        Me.LoadUserList.TabIndex = 14
        Me.LoadUserList.Text = "Load Users"
        Me.LoadUserList.UseVisualStyleBackColor = True
        '
        'EditUserButton
        '
        Me.EditUserButton.Location = New System.Drawing.Point(500, 225)
        Me.EditUserButton.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.EditUserButton.Name = "EditUserButton"
        Me.EditUserButton.Size = New System.Drawing.Size(82, 42)
        Me.EditUserButton.TabIndex = 15
        Me.EditUserButton.Text = "Edit User"
        Me.EditUserButton.UseVisualStyleBackColor = True
        '
        'RemoveUserButton
        '
        Me.RemoveUserButton.Location = New System.Drawing.Point(616, 225)
        Me.RemoveUserButton.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.RemoveUserButton.Name = "RemoveUserButton"
        Me.RemoveUserButton.Size = New System.Drawing.Size(76, 42)
        Me.RemoveUserButton.TabIndex = 16
        Me.RemoveUserButton.Text = "Remove User"
        Me.RemoveUserButton.UseVisualStyleBackColor = True
        '
        'ConfirmCreateButton
        '
        Me.ConfirmCreateButton.Location = New System.Drawing.Point(630, 230)
        Me.ConfirmCreateButton.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ConfirmCreateButton.Name = "ConfirmCreateButton"
        Me.ConfirmCreateButton.Size = New System.Drawing.Size(103, 33)
        Me.ConfirmCreateButton.TabIndex = 17
        Me.ConfirmCreateButton.Text = "Confirm"
        Me.ConfirmCreateButton.UseVisualStyleBackColor = True
        Me.ConfirmCreateButton.Visible = False
        '
        'CancelActionButton
        '
        Me.CancelActionButton.Location = New System.Drawing.Point(377, 230)
        Me.CancelActionButton.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.CancelActionButton.Name = "CancelActionButton"
        Me.CancelActionButton.Size = New System.Drawing.Size(82, 33)
        Me.CancelActionButton.TabIndex = 18
        Me.CancelActionButton.Text = "Cancel"
        Me.CancelActionButton.UseVisualStyleBackColor = True
        Me.CancelActionButton.Visible = False
        '
        'ConfirmEditButton
        '
        Me.ConfirmEditButton.Location = New System.Drawing.Point(630, 230)
        Me.ConfirmEditButton.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ConfirmEditButton.Name = "ConfirmEditButton"
        Me.ConfirmEditButton.Size = New System.Drawing.Size(103, 33)
        Me.ConfirmEditButton.TabIndex = 19
        Me.ConfirmEditButton.Text = "Confirm"
        Me.ConfirmEditButton.UseVisualStyleBackColor = True
        Me.ConfirmEditButton.Visible = False
        '
        'ConfirmDeleteButton
        '
        Me.ConfirmDeleteButton.Location = New System.Drawing.Point(630, 230)
        Me.ConfirmDeleteButton.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ConfirmDeleteButton.Name = "ConfirmDeleteButton"
        Me.ConfirmDeleteButton.Size = New System.Drawing.Size(103, 33)
        Me.ConfirmDeleteButton.TabIndex = 20
        Me.ConfirmDeleteButton.Text = "Confirm"
        Me.ConfirmDeleteButton.UseVisualStyleBackColor = True
        Me.ConfirmDeleteButton.Visible = False
        '
        'BackButton
        '
        Me.BackButton.Location = New System.Drawing.Point(12, 12)
        Me.BackButton.Name = "BackButton"
        Me.BackButton.Size = New System.Drawing.Size(51, 24)
        Me.BackButton.TabIndex = 21
        Me.BackButton.Text = "Back"
        Me.BackButton.UseVisualStyleBackColor = True
        '
        'UserForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(799, 338)
        Me.Controls.Add(Me.BackButton)
        Me.Controls.Add(Me.ConfirmDeleteButton)
        Me.Controls.Add(Me.ConfirmEditButton)
        Me.Controls.Add(Me.CancelActionButton)
        Me.Controls.Add(Me.ConfirmCreateButton)
        Me.Controls.Add(Me.RemoveUserButton)
        Me.Controls.Add(Me.EditUserButton)
        Me.Controls.Add(Me.LoadUserList)
        Me.Controls.Add(Me.CreateNewUserButton)
        Me.Controls.Add(Me.BirthdayPicker)
        Me.Controls.Add(Me.BirthdayLabel)
        Me.Controls.Add(Me.EmailTextBox)
        Me.Controls.Add(Me.EmailLabel)
        Me.Controls.Add(Me.UsernameTextBox)
        Me.Controls.Add(Me.UsernameLabel)
        Me.Controls.Add(Me.LnameTextBox)
        Me.Controls.Add(Me.LnameLabel)
        Me.Controls.Add(Me.FnameLabel)
        Me.Controls.Add(Me.FnameTextBox)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.UsersListBox)
        Me.Controls.Add(Me.TitleFormLabel)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "UserForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Add User Form"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TitleFormLabel As Label
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents UsersListBox As ListBox
    Friend WithEvents Label2 As Label
    Friend WithEvents FnameTextBox As TextBox
    Friend WithEvents FnameLabel As Label
    Friend WithEvents LnameLabel As Label
    Friend WithEvents LnameTextBox As TextBox
    Friend WithEvents UsernameLabel As Label
    Friend WithEvents UsernameTextBox As TextBox
    Friend WithEvents EmailLabel As Label
    Friend WithEvents EmailTextBox As TextBox
    Friend WithEvents BirthdayLabel As Label
    Friend WithEvents BirthdayPicker As DateTimePicker
    Friend WithEvents CreateNewUserButton As Button
    Friend WithEvents LoadUserList As Button
    Friend WithEvents EditUserButton As Button
    Friend WithEvents RemoveUserButton As Button
    Friend WithEvents ConfirmCreateButton As Button
    Friend WithEvents CancelActionButton As Button
    Friend WithEvents ConfirmEditButton As Button
    Friend WithEvents ConfirmDeleteButton As Button
    Friend WithEvents BackButton As Button
End Class
