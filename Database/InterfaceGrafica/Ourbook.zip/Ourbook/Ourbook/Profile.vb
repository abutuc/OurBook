﻿Imports System.Data.SqlClient
Public Class Profile
    Dim CN As SqlConnection
    Dim CMD As SqlCommand
    Private Sub Profile_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CN = New SqlConnection("data source=tcp:mednat.ieeta.pt\SQLSERVER,8101;integrated security=false;initial catalog=p5g1; uid = p5g1; password = AndreGoncaloRumoao20")
        CMD = New SqlCommand
        CMD.Connection = CN
        CMD.CommandText = "EXEC UserStatistics 1"
        CN.Open()
        Dim RDR As SqlDataReader
        RDR = CMD.ExecuteReader()
        Debug.Print(RDR.ToString())
        While RDR.Read()
            TextBox1.Text = RDR.Item("NumberOfDeposits")
            TextBox2.Text = RDR.Item("NumberOfExchanges")
        End While
        CN.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Close()
    End Sub
End Class