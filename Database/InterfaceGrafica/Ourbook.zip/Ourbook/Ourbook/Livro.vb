﻿Public Class Livro
    Private _userID As Integer
    Private _codigo As Integer
    Private _nome As String
    Private _autor As String
    Private _edicao As Integer
    Private _editora As String

    Property UserID As Integer
        Get
            Return _userID
        End Get
        Set(value As Integer)
            _userID = value
        End Set
    End Property

    Property Codigo As Integer
        Get
            Return _codigo
        End Get
        Set(value As Integer)
            _codigo = value
        End Set
    End Property

    Property Nome As String
        Get
            Return _nome
        End Get
        Set(value As String)
            _nome = value
        End Set
    End Property


    Property Autor As String
        Get
            Return _autor
        End Get
        Set(value As String)
            _autor = value
        End Set
    End Property

    Property Edicao As Integer
        Get
            Return _edicao
        End Get
        Set(value As Integer)
            _edicao = value
        End Set
    End Property

    Property Editora As String
        Get
            Return _editora
        End Get
        Set(value As String)
            _editora = value
        End Set
    End Property

    Overrides Function ToString() As String
        Return Nome
    End Function

    Public Sub New()
        MyBase.New()
    End Sub

    Public Sub New(ByVal UserID As Integer, ByVal Codigo As Integer, ByVal Nome As String, ByVal Autor As String, ByVal Edicao As Integer,
                   ByVal Editora As String)
        MyBase.New()
        Me.UserID = UserID
        Me.Codigo = Codigo
        Me.Nome = Nome
        Me.Autor = Autor
        Me.Edicao = Edicao
        Me.Editora = Editora
    End Sub

End Class
