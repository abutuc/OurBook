﻿Imports System.Data.SqlClient
Public Class CourierForm
    Dim CN As SqlConnection
    Dim CMD As SqlCommand
    Dim currentCourier As Integer

    Private Sub CourierForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CN = New SqlConnection("data source=tcp:mednat.ieeta.pt\SQLSERVER,8101;integrated security=false;initial catalog=p5g1; uid = p5g1; password = AndreGoncaloRumoao20")
        CMD = New SqlCommand
        CMD.Connection = CN
        LoadList()
    End Sub

    Private Sub LoadCouriersList_Click(sender As Object, e As EventArgs) Handles LoadCouriersList.Click
        LoadList()
        ClearTextBoxes()
        CouriersListBox.SelectedIndex = -1
    End Sub

    Private Sub LoadList()
        CMD.CommandText = "EXEC GetEstafetaList"
        CN.Open()
        Dim RDR As SqlDataReader
        RDR = CMD.ExecuteReader()
        Debug.Print(RDR.ToString())
        CouriersListBox.Items.Clear()
        While RDR.Read()
            Dim C As New Courier
            C.CourierID = RDR.Item("ID")
            C.CourierName = RDR.Item("Nome")
            CouriersListBox.Items.Add(C)
        End While
        CN.Close()
    End Sub

    Private Sub BlockTextBoxes()
        NameTextBox.Enabled = False
    End Sub

    Private Sub UnblockTextBoxes()
        NameTextBox.Enabled = True
    End Sub

    Private Sub ClearTextBoxes()
        NameTextBox.Text = ""
    End Sub

    Private Function GenerateID() As Integer
        Dim id As New Integer
        CMD.CommandText = "EXEC GetMaxEstafetaID"
        CN.Open()
        Dim RDR As SqlDataReader
        RDR = CMD.ExecuteReader
        While RDR.Read
            id = RDR.Item("MAX_ID")
        End While
        CN.Close()
        Return id
    End Function

    Sub ShowCourier()
        If CouriersListBox.Items.Count = 0 Or currentCourier < 0 Then Exit Sub
        Dim courier As New Courier
        courier = CType(CouriersListBox.Items.Item(currentCourier), Courier)
        NameTextBox.Text = courier.CourierName
        BlockTextBoxes()
    End Sub

    Private Sub UsersListBox_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CouriersListBox.SelectedIndexChanged
        If CouriersListBox.SelectedIndex > -1 Then
            currentCourier = CouriersListBox.SelectedIndex
            ShowCourier()
        End If
    End Sub

    Private Sub CreateNewUserButton_Click(sender As Object, e As EventArgs) Handles CreateNewCourierButton.Click
        ClearTextBoxes()
        UnblockTextBoxes()
        CancelActionButton.Visible = True
        ConfirmCreateButton.Visible = True
        CreateNewCourierButton.Visible = False
        EditCourierButton.Visible = False
        RemoveCourierButton.Visible = False
        ConfirmEditButton.Visible = False
    End Sub

    Private Sub ConfirmActionButton_Click(sender As Object, e As EventArgs) Handles ConfirmCreateButton.Click
        Dim courier As New Courier
        Try
            courier.CourierID = GenerateID() + 1
            If NameTextBox.Text <> "" Then
                courier.CourierName = NameTextBox.Text
            Else
                MessageBox.Show("Name Value Shouldn't Be Empty")
                Return
            End If

        Catch ex As Exception
            MessageBox.Show("Unable to Create A New Courier Due To The Invalid Data Inputted")
            Return
        End Try

        CMD.CommandText = "EXEC CreateNewEstafeta @ID, @Name"
        CMD.Parameters.Clear()
        CMD.Parameters.AddWithValue("@ID", courier.CourierID)
        CMD.Parameters.AddWithValue("@Name", courier.CourierName)
        CN.Open()
        Try
            CMD.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show("An Error Has Occured While Adding the New Courier.")
            Throw New Exception("Failed to update contact in database. ")
        Finally
            ClearTextBoxes()
            BlockTextBoxes()
            CreateNewCourierButton.Visible = True
            EditCourierButton.Visible = True
            RemoveCourierButton.Visible = True
            ConfirmCreateButton.Visible = False
            CancelActionButton.Visible = False
            CN.Close()
        End Try
        ClearTextBoxes()
        BlockTextBoxes()
        CreateNewCourierButton.Visible = True
        EditCourierButton.Visible = True
        RemoveCourierButton.Visible = True
        ConfirmCreateButton.Visible = False
        CancelActionButton.Visible = False
        ConfirmEditButton.Visible = False
        CN.Close()
        LoadList()
    End Sub

    Private Sub CancelActionButton_Click(sender As Object, e As EventArgs) Handles CancelActionButton.Click
        BlockTextBoxes()
        CreateNewCourierButton.Visible = True
        EditCourierButton.Visible = True
        RemoveCourierButton.Visible = True
        ConfirmCreateButton.Visible = False
        CancelActionButton.Visible = False
        ConfirmEditButton.Visible = False
        ConfirmDeleteButton.Visible = False
    End Sub

    Private Sub EditUserButton_Click(sender As Object, e As EventArgs) Handles EditCourierButton.Click
        If CouriersListBox.SelectedIndex > -1 Then
            UnblockTextBoxes()
            CreateNewCourierButton.Visible = False
            EditCourierButton.Visible = False
            RemoveCourierButton.Visible = False
            ConfirmCreateButton.Visible = False
            CancelActionButton.Visible = True
            ConfirmEditButton.Visible = True
        Else
            MessageBox.Show("You must select a Courier to Edit")
        End If
    End Sub

    Private Sub ConfirmEditButton_Click(sender As Object, e As EventArgs) Handles ConfirmEditButton.Click
        Dim courier As New Courier

        Try
            courier.CourierID = CType(CouriersListBox.Items.Item(currentCourier), Courier).CourierID
            If NameTextBox.Text <> "" Then
                courier.CourierName = NameTextBox.Text
            Else
                MessageBox.Show("Name Value Shouldn't Be Empty")
                Return
            End If

        Catch ex As Exception
            MessageBox.Show("Unable to Create A New Courier Due To The Invalid Data Inputted")
            Return
        End Try

        CMD.CommandText = "EXEC UpdateEstafeta @ID, @Name"
        CMD.Parameters.Clear()
        CMD.Parameters.AddWithValue("@ID", courier.CourierID)
        CMD.Parameters.AddWithValue("@Name", courier.CourierName)
        CN.Open()
        Try
            CMD.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Throw New Exception("Failed to update courier in database. ")
        Finally
            ClearTextBoxes()
            BlockTextBoxes()
            CreateNewCourierButton.Visible = True
            EditCourierButton.Visible = True
            RemoveCourierButton.Visible = True
            ConfirmCreateButton.Visible = False
            CancelActionButton.Visible = False
            ConfirmEditButton.Visible = False
            CN.Close()
        End Try
        ClearTextBoxes()
        BlockTextBoxes()
        CreateNewCourierButton.Visible = True
        EditCourierButton.Visible = True
        RemoveCourierButton.Visible = True
        ConfirmCreateButton.Visible = False
        CancelActionButton.Visible = False
        ConfirmEditButton.Visible = False
        CN.Close()
        LoadList()
    End Sub


    Private Sub RemoveUserButton_Click(sender As Object, e As EventArgs) Handles RemoveCourierButton.Click
        If CouriersListBox.SelectedIndex > -1 Then
            BlockTextBoxes()
            CreateNewCourierButton.Visible = False
            EditCourierButton.Visible = False
            RemoveCourierButton.Visible = False
            ConfirmCreateButton.Visible = False
            CancelActionButton.Visible = True
            ConfirmEditButton.Visible = False
            ConfirmDeleteButton.Visible = True
        Else
            MessageBox.Show("You must select a Courier to Edit")
        End If
    End Sub

    Private Sub ConfirmDeleteButton_Click(sender As Object, e As EventArgs) Handles ConfirmDeleteButton.Click
        Dim courierID As Integer = CType(CouriersListBox.Items.Item(currentCourier), Courier).CourierID
        CMD.CommandText = "EXEC RemoveEstafeta @courierID"
        CMD.Parameters.Clear()
        CMD.Parameters.AddWithValue("@courierID", courierID)
        CN.Open()
        Try
            CMD.ExecuteNonQuery()
        Catch ex As Exception
            Throw New Exception("Failed to delete Courier in database. " & vbCrLf & "ERROR MESSAGE: " & vbCrLf & ex.Message)
        Finally
            CN.Close()
        End Try
        LoadList()
        BlockTextBoxes()
        ClearTextBoxes()
        CreateNewCourierButton.Visible = True
        EditCourierButton.Visible = True
        RemoveCourierButton.Visible = True
        ConfirmCreateButton.Visible = False
        CancelActionButton.Visible = False
        ConfirmEditButton.Visible = False
        ConfirmDeleteButton.Visible = False
    End Sub

    Private Sub BackButton_Click(sender As Object, e As EventArgs) Handles BackButton.Click
        Dim AdminPage As New Form1
        AdminPage.Show()
        Close()
    End Sub
End Class