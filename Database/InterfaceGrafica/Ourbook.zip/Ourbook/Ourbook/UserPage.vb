﻿Public Class UserPage
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim bookForm As New BookPage
        bookForm.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim bookMateForm As New BookMateForm
        bookMateForm.Show()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim profileForm As New Profile
        profileForm.Show()
    End Sub
End Class