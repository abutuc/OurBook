﻿<Serializable> Public Class User
    Private _userID As Integer
    Private _fName As String
    Private _lName As String
    Private _username As String
    Private _email As String
    Private _birthday As Date
    Private _geoLocation As Tuple

    Property UserID As Integer
        Get
            Return _userID
        End Get
        Set(value As Integer)
            _userID = value
        End Set
    End Property


    Property UserFirstName As String
        Get
            Return _fName
        End Get
        Set(value As String)
            _fName = value
        End Set
    End Property

    Property UserLastName As String
        Get
            Return _lName
        End Get
        Set(value As String)
            _lName = value
        End Set
    End Property

    Property Username As String
        Get
            Return _username
        End Get
        Set(value As String)
            _username = value
        End Set
    End Property

    Property UserEmail As String
        Get
            Return _email
        End Get
        Set(value As String)
            _email = value
        End Set
    End Property

    Property UserBirthday As Date
        Get
            Return _birthday
        End Get
        Set(value As Date)
            _birthday = value
        End Set
    End Property

    Property UserLocation As Tuple
        Get
            Return _geoLocation
        End Get
        Set(value As Tuple)
            _geoLocation = value
        End Set
    End Property

    Overrides Function ToString() As String
        Return UserFirstName + " " + UserLastName
    End Function

    Public Sub New()
        MyBase.New()
    End Sub

    Public Sub New(ByVal UserID As Integer, ByVal FirstName As String, ByVal LastName As String,
                   ByVal Username As String, ByVal Email As String, ByVal Birthday As Date)
        MyBase.New()
        Me.UserID = UserID
        Me.UserFirstName = FirstName
        Me.UserLastName = LastName
        Me.Username = Username
        Me.UserEmail = Email
        Me.UserBirthday = Birthday
    End Sub

End Class
