﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BookMateForm
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.UserList = New System.Windows.Forms.ListBox()
        Me.BookList = New System.Windows.Forms.ListBox()
        Me.MakeTrade = New System.Windows.Forms.Button()
        Me.ShowBooks = New System.Windows.Forms.Button()
        Me.NotShowBooks = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SearchBox = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.FilterSelectBox = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(73, 57)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(186, 32)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Find BookMate"
        '
        'UserList
        '
        Me.UserList.FormattingEnabled = True
        Me.UserList.ItemHeight = 15
        Me.UserList.Location = New System.Drawing.Point(73, 110)
        Me.UserList.Name = "UserList"
        Me.UserList.Size = New System.Drawing.Size(363, 259)
        Me.UserList.TabIndex = 1
        '
        'BookList
        '
        Me.BookList.FormattingEnabled = True
        Me.BookList.ItemHeight = 15
        Me.BookList.Location = New System.Drawing.Point(458, 110)
        Me.BookList.Name = "BookList"
        Me.BookList.Size = New System.Drawing.Size(363, 259)
        Me.BookList.TabIndex = 2
        '
        'MakeTrade
        '
        Me.MakeTrade.Location = New System.Drawing.Point(503, 400)
        Me.MakeTrade.Name = "MakeTrade"
        Me.MakeTrade.Size = New System.Drawing.Size(111, 28)
        Me.MakeTrade.TabIndex = 3
        Me.MakeTrade.Text = "Make Trade"
        Me.MakeTrade.UseVisualStyleBackColor = True
        '
        'ShowBooks
        '
        Me.ShowBooks.Location = New System.Drawing.Point(655, 400)
        Me.ShowBooks.Name = "ShowBooks"
        Me.ShowBooks.Size = New System.Drawing.Size(88, 28)
        Me.ShowBooks.TabIndex = 4
        Me.ShowBooks.Text = "Show Books"
        Me.ShowBooks.UseVisualStyleBackColor = True
        '
        'NotShowBooks
        '
        Me.NotShowBooks.Location = New System.Drawing.Point(655, 400)
        Me.NotShowBooks.Name = "NotShowBooks"
        Me.NotShowBooks.Size = New System.Drawing.Size(88, 28)
        Me.NotShowBooks.TabIndex = 5
        Me.NotShowBooks.Text = "Hide Books"
        Me.NotShowBooks.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(520, 132)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(57, 21)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Search"
        '
        'SearchBox
        '
        Me.SearchBox.Location = New System.Drawing.Point(520, 175)
        Me.SearchBox.Name = "SearchBox"
        Me.SearchBox.Size = New System.Drawing.Size(223, 23)
        Me.SearchBox.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(520, 306)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(49, 15)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Filter By"
        '
        'FilterSelectBox
        '
        Me.FilterSelectBox.FormattingEnabled = True
        Me.FilterSelectBox.Items.AddRange(New Object() {"All", "Adventure", "Famous", "Fantasy", "Fictional", "Historic", "Humanity", "Revolutionary_Christianism", "Sports", "Number_of_Books"})
        Me.FilterSelectBox.Location = New System.Drawing.Point(520, 333)
        Me.FilterSelectBox.Name = "FilterSelectBox"
        Me.FilterSelectBox.Size = New System.Drawing.Size(249, 23)
        Me.FilterSelectBox.TabIndex = 9
        '
        'BookMateForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(918, 559)
        Me.Controls.Add(Me.BookList)
        Me.Controls.Add(Me.FilterSelectBox)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.SearchBox)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.NotShowBooks)
        Me.Controls.Add(Me.ShowBooks)
        Me.Controls.Add(Me.MakeTrade)
        Me.Controls.Add(Me.UserList)
        Me.Controls.Add(Me.Label1)
        Me.Name = "BookMateForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "BookMateForm"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents UserList As ListBox
    Friend WithEvents BookList As ListBox
    Friend WithEvents MakeTrade As Button
    Friend WithEvents ShowBooks As Button
    Friend WithEvents NotShowBooks As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents SearchBox As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents FilterSelectBox As ComboBox
End Class
