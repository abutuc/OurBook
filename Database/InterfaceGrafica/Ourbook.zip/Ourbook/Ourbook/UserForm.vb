﻿Imports System.Data.SqlClient


Public Class UserForm
    Dim CN As SqlConnection
    Dim CMD As SqlCommand
    Dim currentUser As Integer

    Private Sub LoadUserList_Click(sender As Object, e As EventArgs) Handles LoadUserList.Click
        LoadList()
        ClearTextBoxes()
        UsersListBox.SelectedIndex = -1
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CN = New SqlConnection("data source=tcp:mednat.ieeta.pt\SQLSERVER,8101;integrated security=false;initial catalog=p5g1; uid = p5g1; password = AndreGoncaloRumoao20")
        CMD = New SqlCommand
        CMD.Connection = CN
        CMD.CommandText = "EXEC GetUserList"
        CN.Open()
        Dim RDR As SqlDataReader
        RDR = CMD.ExecuteReader()
        Debug.Print(RDR.ToString())
        UsersListBox.Items.Clear()
        While RDR.Read()
            Dim U As New User
            U.UserID = RDR.Item("ID")
            U.UserFirstName = RDR.Item("Fname")
            U.UserLastName = RDR.Item("Lname")
            U.Username = RDR.Item("Username")
            U.UserEmail = RDR.Item("Email")
            U.UserBirthday = RDR.Item("Birthday")
            UsersListBox.Items.Add(U)
        End While
        CN.Close()
    End Sub

    Private Sub LoadList()
        CMD.CommandText = "EXEC GetUserList"
        CN.Open()
        Dim RDR As SqlDataReader
        RDR = CMD.ExecuteReader()
        Debug.Print(RDR.ToString())
        UsersListBox.Items.Clear()
        While RDR.Read()
            Dim U As New User
            U.UserID = RDR.Item("ID")
            U.UserFirstName = RDR.Item("Fname")
            U.UserLastName = RDR.Item("Lname")
            U.Username = RDR.Item("Username")
            U.UserEmail = RDR.Item("Email")
            U.UserBirthday = RDR.Item("Birthday")
            UsersListBox.Items.Add(U)
        End While
        CN.Close()
    End Sub


    Private Sub BlockTextBoxes()
        FnameTextBox.Enabled = False
        LnameTextBox.Enabled = False
        UsernameTextBox.Enabled = False
        EmailTextBox.Enabled = False
        BirthdayPicker.Enabled = False
    End Sub

    Private Sub UnblockTextBoxes()
        FnameTextBox.Enabled = True
        LnameTextBox.Enabled = True
        UsernameTextBox.Enabled = True
        EmailTextBox.Enabled = True
        BirthdayPicker.Enabled = True
    End Sub

    Private Sub ClearTextBoxes()
        FnameTextBox.Text = ""
        LnameTextBox.Text = ""
        UsernameTextBox.Text = ""
        EmailTextBox.Text = ""
        BirthdayPicker.Value = Today()
    End Sub

    Private Function GenerateID() As Integer
        Dim id As New Integer
        CMD.CommandText = "EXEC GetMaxUserID"
        CN.Open()
        Dim RDR As SqlDataReader
        RDR = CMD.ExecuteReader
        While RDR.Read
            id = RDR.Item("MAX_ID")
        End While
        CN.Close()
        Return id
    End Function

    Sub ShowUser()
        If UsersListBox.Items.Count = 0 Or currentUser < 0 Then Exit Sub
        Dim user As New User
        user = CType(UsersListBox.Items.Item(currentUser), User)
        FnameTextBox.Text = user.UserFirstName
        LnameTextBox.Text = user.UserLastName
        UsernameTextBox.Text = user.Username
        EmailTextBox.Text = user.UserEmail
        BirthdayPicker.Value = user.UserBirthday
        BlockTextBoxes()
    End Sub

    Private Sub UsersListBox_SelectedIndexChanged(sender As Object, e As EventArgs) Handles UsersListBox.SelectedIndexChanged
        If UsersListBox.SelectedIndex > -1 Then
            currentUser = UsersListBox.SelectedIndex
            ShowUser()
        End If
    End Sub

    Private Sub CreateNewUserButton_Click(sender As Object, e As EventArgs) Handles CreateNewUserButton.Click
        ClearTextBoxes()
        UnblockTextBoxes()
        CancelActionButton.Visible = True
        ConfirmCreateButton.Visible = True
        CreateNewUserButton.Visible = False
        EditUserButton.Visible = False
        RemoveUserButton.Visible = False
        ConfirmEditButton.Visible = False
    End Sub

    Private Sub ConfirmActionButton_Click(sender As Object, e As EventArgs) Handles ConfirmCreateButton.Click
        Dim user As New User
        Try
            user.UserID = GenerateID() + 1
            If FnameTextBox.Text <> "" Then
                user.UserFirstName = FnameTextBox.Text
            Else
                MessageBox.Show("First Name Value Shouldn't Be Empty")
                Return
            End If

            If LnameTextBox.Text <> "" Then
                user.UserLastName = LnameTextBox.Text
            Else
                MessageBox.Show("Last Name Value Shouldn't Be Empty")
                Return
            End If

            If UsernameTextBox.Text <> "" Then
                user.Username = UsernameTextBox.Text
            Else
                MessageBox.Show("Username Value Shouldn't Be Empty")
                Return
            End If

            If EmailTextBox.Text <> "" Then
                user.UserEmail = EmailTextBox.Text
            Else
                MessageBox.Show("Email Value Shouldn't Be Empty")
                Return
            End If

            user.UserBirthday = BirthdayPicker.Value

        Catch ex As Exception
            MessageBox.Show("Unable to Create A New User Due To The Invalid Data Inputted")
            Return
        End Try

        CMD.CommandText = "EXEC CreateNewUser @ID, @Fname, @Lname, @Username, @Email, @Birthday"
        CMD.Parameters.Clear()
        CMD.Parameters.AddWithValue("@ID", user.UserID)
        CMD.Parameters.AddWithValue("@Fname", user.UserFirstName)
        CMD.Parameters.AddWithValue("@Lname", user.UserLastName)
        CMD.Parameters.AddWithValue("@Username", user.Username)
        CMD.Parameters.AddWithValue("@Email", user.UserEmail)
        CMD.Parameters.AddWithValue("@Birthday", user.UserBirthday)
        CN.Open()
        Try
            CMD.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show("An Error Has Occured While Adding the New User-")
            Throw New Exception("Failed to update user in database. ")
        Finally
            ClearTextBoxes()
            BlockTextBoxes()
            CreateNewUserButton.Visible = True
            EditUserButton.Visible = True
            RemoveUserButton.Visible = True
            ConfirmCreateButton.Visible = False
            CancelActionButton.Visible = False
            CN.Close()
        End Try
        ClearTextBoxes()
        BlockTextBoxes()
        CreateNewUserButton.Visible = True
        EditUserButton.Visible = True
        RemoveUserButton.Visible = True
        ConfirmCreateButton.Visible = False
        CancelActionButton.Visible = False
        ConfirmEditButton.Visible = False
        CN.Close()
        LoadList()
    End Sub

    Private Sub CancelActionButton_Click(sender As Object, e As EventArgs) Handles CancelActionButton.Click
        BlockTextBoxes()
        CreateNewUserButton.Visible = True
        EditUserButton.Visible = True
        RemoveUserButton.Visible = True
        ConfirmCreateButton.Visible = False
        CancelActionButton.Visible = False
        ConfirmEditButton.Visible = False
        ConfirmDeleteButton.Visible = False
    End Sub

    Private Sub EditUserButton_Click(sender As Object, e As EventArgs) Handles EditUserButton.Click
        If UsersListBox.SelectedIndex > -1 Then
            UnblockTextBoxes()
            CreateNewUserButton.Visible = False
            EditUserButton.Visible = False
            RemoveUserButton.Visible = False
            ConfirmCreateButton.Visible = False
            CancelActionButton.Visible = True
            ConfirmEditButton.Visible = True
        Else
            MessageBox.Show("You must select a User to Edit")
        End If
    End Sub

    Private Sub ConfirmEditButton_Click(sender As Object, e As EventArgs) Handles ConfirmEditButton.Click
        Dim user As New User

        Try
            user.UserID = CType(UsersListBox.Items.Item(currentUser), User).UserID
            If FnameTextBox.Text <> "" Then
                user.UserFirstName = FnameTextBox.Text
            Else
                MessageBox.Show("First Name Value Shouldn't Be Empty")
                Return
            End If

            If LnameTextBox.Text <> "" Then
                user.UserLastName = LnameTextBox.Text
            Else
                MessageBox.Show("Last Name Value Shouldn't Be Empty")
                Return
            End If

            If UsernameTextBox.Text <> "" Then
                user.Username = UsernameTextBox.Text
            Else
                MessageBox.Show("Username Value Shouldn't Be Empty")
                Return
            End If

            If EmailTextBox.Text <> "" Then
                user.UserEmail = EmailTextBox.Text
            Else
                MessageBox.Show("Email Value Shouldn't Be Empty")
                Return
            End If

            user.UserBirthday = BirthdayPicker.Value

        Catch ex As Exception
            MessageBox.Show("Unable to Create A New User Due To The Invalid Data Inputted")
            Return
        End Try

        CMD.CommandText = "EXEC UpdateUser @ID, @Fname, @Lname, @Username, @Email, @Birthday"
        CMD.Parameters.Clear()
        CMD.Parameters.AddWithValue("@ID", user.UserID)
        CMD.Parameters.AddWithValue("@Fname", user.UserFirstName)
        CMD.Parameters.AddWithValue("@Lname", user.UserLastName)
        CMD.Parameters.AddWithValue("@Username", user.Username)
        CMD.Parameters.AddWithValue("@Email", user.UserEmail)
        CMD.Parameters.AddWithValue("@Birthday", user.UserBirthday)
        CN.Open()
        Try
            CMD.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Throw New Exception("Failed to update courier in database. ")
        Finally
            ClearTextBoxes()
            BlockTextBoxes()
            CreateNewUserButton.Visible = True
            EditUserButton.Visible = True
            RemoveUserButton.Visible = True
            ConfirmCreateButton.Visible = False
            CancelActionButton.Visible = False
            ConfirmEditButton.Visible = False
            CN.Close()
        End Try
        ClearTextBoxes()
        BlockTextBoxes()
        CreateNewUserButton.Visible = True
        EditUserButton.Visible = True
        RemoveUserButton.Visible = True
        ConfirmCreateButton.Visible = False
        CancelActionButton.Visible = False
        ConfirmEditButton.Visible = False
        CN.Close()
        LoadList()
    End Sub


    Private Sub RemoveUserButton_Click(sender As Object, e As EventArgs) Handles RemoveUserButton.Click
        If UsersListBox.SelectedIndex > -1 Then
            BlockTextBoxes()
            CreateNewUserButton.Visible = False
            EditUserButton.Visible = False
            RemoveUserButton.Visible = False
            ConfirmCreateButton.Visible = False
            CancelActionButton.Visible = True
            ConfirmEditButton.Visible = False
            ConfirmDeleteButton.Visible = True
        Else
            MessageBox.Show("You must select a User to Edit")
        End If
    End Sub

    Private Sub ConfirmDeleteButton_Click(sender As Object, e As EventArgs) Handles ConfirmDeleteButton.Click
        Dim userID As Integer = CType(UsersListBox.Items.Item(currentUser), User).UserID
        CMD.CommandText = "EXEC RemoveUser @userID "
        CMD.Parameters.Clear()
        CMD.Parameters.AddWithValue("@userID", userID)
        CN.Open()
        Try
            CMD.ExecuteNonQuery()
        Catch ex As Exception
            Throw New Exception("Failed to delete courier in database. " & vbCrLf & "ERROR MESSAGE: " & vbCrLf & ex.Message)
        Finally
            CN.Close()
        End Try
        LoadList()
        BlockTextBoxes()
        ClearTextBoxes()
        CreateNewUserButton.Visible = True
        EditUserButton.Visible = True
        RemoveUserButton.Visible = True
        ConfirmCreateButton.Visible = False
        CancelActionButton.Visible = False
        ConfirmEditButton.Visible = False
        ConfirmDeleteButton.Visible = False
    End Sub

    Private Sub BackButton_Click(sender As Object, e As EventArgs) Handles BackButton.Click
        Dim AdminPage As New Form1
        AdminPage.Show()
        Close()
    End Sub
End Class
