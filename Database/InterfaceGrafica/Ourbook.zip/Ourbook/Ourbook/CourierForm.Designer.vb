﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CourierForm
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ConfirmDeleteButton = New System.Windows.Forms.Button()
        Me.ConfirmEditButton = New System.Windows.Forms.Button()
        Me.CancelActionButton = New System.Windows.Forms.Button()
        Me.ConfirmCreateButton = New System.Windows.Forms.Button()
        Me.RemoveCourierButton = New System.Windows.Forms.Button()
        Me.EditCourierButton = New System.Windows.Forms.Button()
        Me.LoadCouriersList = New System.Windows.Forms.Button()
        Me.CreateNewCourierButton = New System.Windows.Forms.Button()
        Me.NameTextBox = New System.Windows.Forms.TextBox()
        Me.NameLabel = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.CouriersListBox = New System.Windows.Forms.ListBox()
        Me.TitleFormLabel = New System.Windows.Forms.Label()
        Me.BackButton = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'ConfirmDeleteButton
        '
        Me.ConfirmDeleteButton.Location = New System.Drawing.Point(588, 218)
        Me.ConfirmDeleteButton.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ConfirmDeleteButton.Name = "ConfirmDeleteButton"
        Me.ConfirmDeleteButton.Size = New System.Drawing.Size(103, 33)
        Me.ConfirmDeleteButton.TabIndex = 41
        Me.ConfirmDeleteButton.Text = "Confirm"
        Me.ConfirmDeleteButton.UseVisualStyleBackColor = True
        Me.ConfirmDeleteButton.Visible = False
        '
        'ConfirmEditButton
        '
        Me.ConfirmEditButton.Location = New System.Drawing.Point(588, 218)
        Me.ConfirmEditButton.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ConfirmEditButton.Name = "ConfirmEditButton"
        Me.ConfirmEditButton.Size = New System.Drawing.Size(103, 33)
        Me.ConfirmEditButton.TabIndex = 40
        Me.ConfirmEditButton.Text = "Confirm"
        Me.ConfirmEditButton.UseVisualStyleBackColor = True
        Me.ConfirmEditButton.Visible = False
        '
        'CancelActionButton
        '
        Me.CancelActionButton.Location = New System.Drawing.Point(335, 218)
        Me.CancelActionButton.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.CancelActionButton.Name = "CancelActionButton"
        Me.CancelActionButton.Size = New System.Drawing.Size(82, 33)
        Me.CancelActionButton.TabIndex = 39
        Me.CancelActionButton.Text = "Cancel"
        Me.CancelActionButton.UseVisualStyleBackColor = True
        Me.CancelActionButton.Visible = False
        '
        'ConfirmCreateButton
        '
        Me.ConfirmCreateButton.Location = New System.Drawing.Point(588, 218)
        Me.ConfirmCreateButton.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ConfirmCreateButton.Name = "ConfirmCreateButton"
        Me.ConfirmCreateButton.Size = New System.Drawing.Size(103, 33)
        Me.ConfirmCreateButton.TabIndex = 38
        Me.ConfirmCreateButton.Text = "Confirm"
        Me.ConfirmCreateButton.UseVisualStyleBackColor = True
        Me.ConfirmCreateButton.Visible = False
        '
        'RemoveCourierButton
        '
        Me.RemoveCourierButton.Location = New System.Drawing.Point(574, 213)
        Me.RemoveCourierButton.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.RemoveCourierButton.Name = "RemoveCourierButton"
        Me.RemoveCourierButton.Size = New System.Drawing.Size(76, 42)
        Me.RemoveCourierButton.TabIndex = 37
        Me.RemoveCourierButton.Text = "Remove Courier"
        Me.RemoveCourierButton.UseVisualStyleBackColor = True
        '
        'EditCourierButton
        '
        Me.EditCourierButton.Location = New System.Drawing.Point(458, 213)
        Me.EditCourierButton.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.EditCourierButton.Name = "EditCourierButton"
        Me.EditCourierButton.Size = New System.Drawing.Size(82, 42)
        Me.EditCourierButton.TabIndex = 36
        Me.EditCourierButton.Text = "Edit Courier"
        Me.EditCourierButton.UseVisualStyleBackColor = True
        '
        'LoadCouriersList
        '
        Me.LoadCouriersList.Location = New System.Drawing.Point(58, 105)
        Me.LoadCouriersList.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.LoadCouriersList.Name = "LoadCouriersList"
        Me.LoadCouriersList.Size = New System.Drawing.Size(116, 22)
        Me.LoadCouriersList.TabIndex = 35
        Me.LoadCouriersList.Text = "Load Couriers"
        Me.LoadCouriersList.UseVisualStyleBackColor = True
        '
        'CreateNewCourierButton
        '
        Me.CreateNewCourierButton.Location = New System.Drawing.Point(325, 213)
        Me.CreateNewCourierButton.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.CreateNewCourierButton.Name = "CreateNewCourierButton"
        Me.CreateNewCourierButton.Size = New System.Drawing.Size(108, 42)
        Me.CreateNewCourierButton.TabIndex = 34
        Me.CreateNewCourierButton.Text = "Create New Courier"
        Me.CreateNewCourierButton.UseVisualStyleBackColor = True
        '
        'NameTextBox
        '
        Me.NameTextBox.Location = New System.Drawing.Point(396, 145)
        Me.NameTextBox.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.NameTextBox.Name = "NameTextBox"
        Me.NameTextBox.Size = New System.Drawing.Size(220, 23)
        Me.NameTextBox.TabIndex = 27
        '
        'NameLabel
        '
        Me.NameLabel.AutoSize = True
        Me.NameLabel.Location = New System.Drawing.Point(335, 148)
        Me.NameLabel.Name = "NameLabel"
        Me.NameLabel.Size = New System.Drawing.Size(42, 15)
        Me.NameLabel.TabIndex = 25
        Me.NameLabel.Text = "Name:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(58, 74)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(169, 15)
        Me.Label2.TabIndex = 23
        Me.Label2.Text = "Currently registered Couriers"
        '
        'CouriersListBox
        '
        Me.CouriersListBox.FormattingEnabled = True
        Me.CouriersListBox.ItemHeight = 15
        Me.CouriersListBox.Location = New System.Drawing.Point(58, 132)
        Me.CouriersListBox.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.CouriersListBox.Name = "CouriersListBox"
        Me.CouriersListBox.Size = New System.Drawing.Size(190, 244)
        Me.CouriersListBox.TabIndex = 22
        '
        'TitleFormLabel
        '
        Me.TitleFormLabel.AutoSize = True
        Me.TitleFormLabel.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.TitleFormLabel.Location = New System.Drawing.Point(433, 74)
        Me.TitleFormLabel.Name = "TitleFormLabel"
        Me.TitleFormLabel.Size = New System.Drawing.Size(123, 25)
        Me.TitleFormLabel.TabIndex = 21
        Me.TitleFormLabel.Text = "Courier Form"
        '
        'BackButton
        '
        Me.BackButton.Location = New System.Drawing.Point(22, 26)
        Me.BackButton.Name = "BackButton"
        Me.BackButton.Size = New System.Drawing.Size(51, 24)
        Me.BackButton.TabIndex = 42
        Me.BackButton.Text = "Back"
        Me.BackButton.UseVisualStyleBackColor = True
        '
        'CourierForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(725, 400)
        Me.Controls.Add(Me.BackButton)
        Me.Controls.Add(Me.ConfirmDeleteButton)
        Me.Controls.Add(Me.ConfirmEditButton)
        Me.Controls.Add(Me.CancelActionButton)
        Me.Controls.Add(Me.ConfirmCreateButton)
        Me.Controls.Add(Me.RemoveCourierButton)
        Me.Controls.Add(Me.EditCourierButton)
        Me.Controls.Add(Me.LoadCouriersList)
        Me.Controls.Add(Me.CreateNewCourierButton)
        Me.Controls.Add(Me.NameTextBox)
        Me.Controls.Add(Me.NameLabel)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.CouriersListBox)
        Me.Controls.Add(Me.TitleFormLabel)
        Me.Name = "CourierForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "CourierForm"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ConfirmDeleteButton As Button
    Friend WithEvents ConfirmEditButton As Button
    Friend WithEvents CancelActionButton As Button
    Friend WithEvents ConfirmCreateButton As Button
    Friend WithEvents RemoveCourierButton As Button
    Friend WithEvents EditCourierButton As Button
    Friend WithEvents LoadCouriersList As Button
    Friend WithEvents CreateNewCourierButton As Button
    Friend WithEvents NameTextBox As TextBox
    Friend WithEvents NameLabel As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents CouriersListBox As ListBox
    Friend WithEvents TitleFormLabel As Label
    Friend WithEvents BackButton As Button
End Class
