﻿Public Class Courier
    Private _courierID As Integer
    Private _courierName As String
    Private _geoLocation As String

    Property CourierID As Integer
        Get
            Return _courierID
        End Get
        Set(value As Integer)
            _courierID = value
        End Set
    End Property

    Property CourierName As String
        Get
            Return _courierName
        End Get
        Set(value As String)
            _courierName = value
        End Set
    End Property

    Property GeoLocation As String
        Get
            Return _geoLocation
        End Get
        Set(value As String)
            _geoLocation = value
        End Set
    End Property

    Overrides Function ToString() As String
        Return CourierName
    End Function

    Public Sub New()
        MyBase.New()
    End Sub

    Public Sub New(ByVal CourierID As Integer, ByVal CourierName As String, ByVal GeoLocation As String)
        MyBase.New()
        Me.CourierID = CourierID
        Me.CourierName = CourierName
        Me.GeoLocation = GeoLocation
    End Sub
End Class
